plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.civilsafety.app"

    compileSdk = 36
//    ndkVersion = flutter.ndkVersion

    defaultConfig {
        applicationId = "com.civilsafety.app"
        minSdk = 24
        targetSdk = 36

        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    // 저작권 등록 제출본: 배포용 서명정보(keystore/비밀번호)는 보안상 제외함.

    buildTypes {
        debug {
            // debug 기본 설정
        }
        release {
            // 등록용 소스에는 배포 서명 설정을 포함하지 않음.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-location:21.3.0")
}

flutter {
    source = "../.."
}
