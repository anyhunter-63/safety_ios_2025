프로그램명: 안전지키미 (Safety Keeper)

본 복제물은 Android 및 iOS에서 공통으로 사용하는 Flutter 기반 통합 소스코드입니다.

[주요 구성]
- lib/ : Flutter/Dart 공통 프로그램 소스
- assets/ : 프로그램에서 실제 사용하는 이미지·음원 리소스
- android/ : Android 플랫폼 연동 소스 및 설정
- ios/ : iOS 플랫폼 연동 소스 및 설정
- pubspec.yaml / pubspec.lock : Flutter 프로젝트 및 의존성 정보

[보안 및 제출 목적상 제외한 항목]
- Android 배포용 keystore 및 서명 비밀번호
- local.properties 등 개발 PC 로컬 설정
- .gradle, .dart_tool, build 등 캐시·빌드 산출물
- iOS Generated.xcconfig, flutter_export_environment.sh, ephemeral 등 자동생성·임시파일
- IDE 설정파일 및 불필요한 자동생성 파일
- 중복 assets 폴더

※ 본 제출본의 Android build.gradle.kts에서는 배포용 서명정보만 제거하였으며,
   프로그램 소스 및 주요 실행 구조에는 영향을 주지 않습니다.
